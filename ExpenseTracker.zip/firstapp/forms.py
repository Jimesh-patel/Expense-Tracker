# from django import forms

# class signupForm(forms.Form):
    
#     username            = forms.CharField(max_length=100)
#     password            = forms.CharField(max_length=50)
#     email               = forms.EmailField(max_length=100)
#     phone_no            = forms.CharField(max_length=12)

# class loginForm(forms.Form):
    
#     username            = forms.CharField(max_length=100)
#     password            = forms.CharField(max_length=50)
